var searchData=
[
  ['render',['render',['../classgdf_1_1kernel_1_1_game_info.html#a5f1a4283a4038b76996392bc5c6d16fb',1,'gdf::kernel::GameInfo::render()'],['../classgdf_1_1kernel_1_1_scene.html#a422db92a1a3388cb6cfc099311b3c139',1,'gdf::kernel::Scene::render()']]],
  ['render_5fgui',['render_gui',['../classgdf_1_1kernel_1_1_scene.html#a7b72d50c98a5232274cc1df00012242d',1,'gdf::kernel::Scene']]],
  ['root',['root',['../classgdf_1_1kernel_1_1_scene.html#a00dfb5538e4366bf9f872a193e1aa60e',1,'gdf::kernel::Scene']]],
  ['root_5f',['root_',['../classgdf_1_1kernel_1_1_scene.html#a43a3e678d3d9e53df086ee170a350f60',1,'gdf::kernel::Scene']]]
];
