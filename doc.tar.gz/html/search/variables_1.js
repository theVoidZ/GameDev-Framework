var searchData=
[
  ['cameras_5f',['cameras_',['../classgdf_1_1kernel_1_1_scene.html#a7700a1869b9544422afbf8120968466f',1,'gdf::kernel::Scene']]],
  ['children_5fcomponents_5f',['children_components_',['../classgdf_1_1kernel_1_1_component.html#a0c0f326e793671fc7190f2a9df4221a7',1,'gdf::kernel::Component']]],
  ['clear_5fcolor_5f',['clear_color_',['../classgdf_1_1kernel_1_1_scene.html#a630d90b37d8d3522d39e0d6074705de1',1,'gdf::kernel::Scene']]]
];
