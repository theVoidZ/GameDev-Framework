var searchData=
[
  ['object',['Object',['../classgdf_1_1kernel_1_1_object.html',1,'gdf::kernel']]]
];
