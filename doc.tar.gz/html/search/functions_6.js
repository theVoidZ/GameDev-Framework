var searchData=
[
  ['handle_5fevents',['handle_events',['../classgdf_1_1kernel_1_1_game_info.html#a41cb927e1a7c96ad74d7e03e0761ef76',1,'gdf::kernel::GameInfo::handle_events()'],['../classgdf_1_1kernel_1_1_scene.html#aabafb71f75e2bba8753c5bec81149bcb',1,'gdf::kernel::Scene::handle_events()']]],
  ['host_5fobject',['host_object',['../classgdf_1_1kernel_1_1_component.html#a6cd0010b9f27ed610021d8805ad709ac',1,'gdf::kernel::Component']]]
];
