var searchData=
[
  ['kernelrules_2eh',['kernelrules.h',['../kernelrules_8h.html',1,'']]]
];
