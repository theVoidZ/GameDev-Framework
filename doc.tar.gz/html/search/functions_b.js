var searchData=
[
  ['make_5flinking',['make_linking',['../classgdf_1_1kernel_1_1_component_container.html#a14806220a92f38f057b72bec616c936f',1,'gdf::kernel::ComponentContainer']]],
  ['make_5fsingleton',['make_singleton',['../classgdf_1_1kernel_1_1_kernel_rules.html#a06c0e3a2149dc0f4dc71f2bbc65b0c98',1,'gdf::kernel::KernelRules']]]
];
