var searchData=
[
  ['gdf',['gdf',['../namespacegdf.html',1,'']]],
  ['kernel',['kernel',['../namespacegdf_1_1kernel.html',1,'gdf']]]
];
