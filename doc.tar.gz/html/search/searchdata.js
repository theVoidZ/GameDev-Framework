var indexSectionsWithContent =
{
  0: "abcdfghijklmnoprstuv~",
  1: "cgkos",
  2: "g",
  3: "cgkos",
  4: "abcdfghijklmnoprstuv~",
  5: "acdghijknprst",
  6: "cg",
  7: "b"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "related",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Friends",
  7: "Pages"
};

