var searchData=
[
  ['name',['name',['../classgdf_1_1kernel_1_1_object.html#a8aa9a6c7dfdbcf8dc53dfc78dd98975d',1,'gdf::kernel::Object::name()'],['../classgdf_1_1kernel_1_1_scene.html#a696afc056e226b181601869497188395',1,'gdf::kernel::Scene::name()']]]
];
