var searchData=
[
  ['dim',['DIM',['../terminal__colors_8h.html#ac25189db92959bff3c6c2adf4c34b50a',1,'terminal_colors.h']]]
];
