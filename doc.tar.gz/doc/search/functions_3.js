var searchData=
[
  ['destroy',['destroy',['../classgdf_1_1kernel_1_1_game_object.html#a0969096e3e9063cc30d877733f983f60',1,'gdf::kernel::GameObject::destroy(GameObject *go, unsigned long long ttd_ms=0)'],['../classgdf_1_1kernel_1_1_game_object.html#a62dceed4a63b20e2d3c39aa14d69e0e1',1,'gdf::kernel::GameObject::destroy(Component *comp, unsigned long long ttd_ms=0)']]],
  ['detach',['detach',['../classgdf_1_1kernel_1_1_hierarchy.html#ac45bf64bfb37196ec9f7dbe74c62536b',1,'gdf::kernel::Hierarchy']]],
  ['detach_5fchild',['detach_child',['../classgdf_1_1kernel_1_1_hierarchy.html#a2dc3c49f8be459d5b7aafa39aa88412e',1,'gdf::kernel::Hierarchy']]],
  ['detach_5fchildren',['detach_children',['../classgdf_1_1kernel_1_1_hierarchy.html#a99192190ac10a05410d9530bf4c06710',1,'gdf::kernel::Hierarchy']]],
  ['draw',['draw',['../class_my_component.html#a726a0fdddef635b6b5ba1cc3e70b49fb',1,'MyComponent::draw()'],['../classgdf_1_1kernel_1_1_component.html#a1b7193db599fbfe729e5b514e7ddeb0e',1,'gdf::kernel::Component::draw()'],['../classgdf_1_1kernel_1_1_game_object.html#af4c1764886f89a8d90addf1a164c6b92',1,'gdf::kernel::GameObject::draw()']]]
];
