var searchData=
[
  ['name_5f',['name_',['../classgdf_1_1kernel_1_1_object.html#a0dd4628e53432c14af89c1615b1bb831',1,'gdf::kernel::Object::name_()'],['../classgdf_1_1kernel_1_1_scene.html#a2a80be923df755ae3c6448c51615306c',1,'gdf::kernel::Scene::name_()']]]
];
