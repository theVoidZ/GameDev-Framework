var searchData=
[
  ['hidden',['HIDDEN',['../terminal__colors_8h.html#ab42ef41116f8f2fe447484e2844cf0df',1,'terminal_colors.h']]]
];
