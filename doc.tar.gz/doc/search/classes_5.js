var searchData=
[
  ['kernelrules',['KernelRules',['../classgdf_1_1kernel_1_1_kernel_rules.html',1,'gdf::kernel']]]
];
