var searchData=
[
  ['render',['render',['../classgdf_1_1kernel_1_1_game_info.html#a5f1a4283a4038b76996392bc5c6d16fb',1,'gdf::kernel::GameInfo::render()'],['../classgdf_1_1kernel_1_1_scene.html#a422db92a1a3388cb6cfc099311b3c139',1,'gdf::kernel::Scene::render()']]],
  ['render_5fgui',['render_gui',['../classgdf_1_1kernel_1_1_scene.html#a7b72d50c98a5232274cc1df00012242d',1,'gdf::kernel::Scene']]],
  ['right',['right',['../class_transform.html#a4578397f3c0403a8c81e1a824a353f14',1,'Transform']]],
  ['root',['root',['../classgdf_1_1kernel_1_1_hierarchy.html#acbe9f36d3e5c4fbf661a295fb34304b1',1,'gdf::kernel::Hierarchy::root()'],['../classgdf_1_1kernel_1_1_scene.html#a00dfb5538e4366bf9f872a193e1aa60e',1,'gdf::kernel::Scene::root()']]],
  ['rotate',['rotate',['../class_camera.html#a300db79a67c27fcb1e535591f1031c8f',1,'Camera::rotate()'],['../class_transform.html#a5000399dab8eeed24dd42a6c3323e33b',1,'Transform::rotate()']]],
  ['rotate_5faround',['rotate_around',['../class_transform.html#a1cb5086a6cccf3b2f71aa78e215eac53',1,'Transform']]]
];
