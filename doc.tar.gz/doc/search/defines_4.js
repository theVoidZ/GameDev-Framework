var searchData=
[
  ['italic',['ITALIC',['../terminal__colors_8h.html#af706885b9b3eb2821dff28f8e7f7bb3f',1,'terminal_colors.h']]]
];
