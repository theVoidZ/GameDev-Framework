var searchData=
[
  ['init',['init',['../class_camera.html#af930ce1f46c9f5af3bd5e5bbff6b5022',1,'Camera::init()'],['../class_my_component.html#aa7535def48982a42d3143e52de2f93cd',1,'MyComponent::init()'],['../classgdf_1_1kernel_1_1_component.html#ac24a5ed8a985f4ee1d809cc13cfbb2e6',1,'gdf::kernel::Component::init()'],['../classgdf_1_1kernel_1_1_game_info.html#a7d6eac7281d1c0cd71e7b40b1fe32b59',1,'gdf::kernel::GameInfo::init()'],['../classgdf_1_1kernel_1_1_game_object.html#a7023423fca1b7ad95f08cccb3ea5fd89',1,'gdf::kernel::GameObject::init()'],['../classgdf_1_1kernel_1_1_kernel_rules.html#a8cb913b53cc13cd8b4f276d9fb9011a4',1,'gdf::kernel::KernelRules::init()'],['../classgdf_1_1kernel_1_1_scene.html#aaf12a8181fa356239545b0a5007f9bbf',1,'gdf::kernel::Scene::init()']]],
  ['instance_5fid',['instance_id',['../classgdf_1_1kernel_1_1_object.html#a437c3e4fb937f66e81febdd62255450d',1,'gdf::kernel::Object']]],
  ['instance_5fid_5f',['instance_id_',['../classgdf_1_1kernel_1_1_object.html#aac83dc5891cd863934d0aa383a0e62c5',1,'gdf::kernel::Object']]],
  ['instantiate',['instantiate',['../classgdf_1_1kernel_1_1_game_object.html#a99fc69693941876ca14e8abaaf00a481',1,'gdf::kernel::GameObject::instantiate()'],['../classgdf_1_1kernel_1_1_game_object.html#a2f8f782e14e686a92696fe7ee3600a27',1,'gdf::kernel::GameObject::instantiate(std::string go_name, sf::Vector2f pos=sf::Vector2f(0, 0), float rotation=0)'],['../classgdf_1_1kernel_1_1_game_object.html#aecf9431297516d33d5bb8cddf0c479c8',1,'gdf::kernel::GameObject::instantiate(Hierarchy *parent, std::string go_name=&quot;&quot;, sf::Vector2f pos=sf::Vector2f(0, 0), float rotation=0)']]],
  ['intersects',['intersects',['../class_bounds.html#a44d58caf606eb7b9f501d560533b40be',1,'Bounds']]],
  ['inverse_5ftransform_5fpoint',['inverse_transform_point',['../class_transform.html#abc6c3936579e29d2ecb75950249759de',1,'Transform']]],
  ['inverse_5ftransform_5fvector',['inverse_transform_vector',['../class_transform.html#a0f2ffde5fb7ebfc04821336ec5a6393d',1,'Transform']]],
  ['is_5fchild_5fof',['is_child_of',['../classgdf_1_1kernel_1_1_hierarchy.html#a12ffc9b601a8212977ec979c63c17bc4',1,'gdf::kernel::Hierarchy']]],
  ['is_5fdaemon',['is_daemon',['../classgdf_1_1kernel_1_1_scene.html#a8be7668b1722008319640742522615cc',1,'gdf::kernel::Scene']]],
  ['is_5fdaemon_5f',['is_daemon_',['../classgdf_1_1kernel_1_1_scene.html#a739cd318544ade99afd4d1eda961a975',1,'gdf::kernel::Scene']]],
  ['is_5fenabled',['is_enabled',['../class_behavior.html#affaded14b9451d0151340f6a3859bf62',1,'Behavior']]],
  ['is_5floaded',['is_loaded',['../classgdf_1_1kernel_1_1_scene.html#a98f446b820a047515eef822dfa5c2176',1,'gdf::kernel::Scene']]],
  ['is_5floaded_5f',['is_loaded_',['../classgdf_1_1kernel_1_1_scene.html#af785dd6bc8f27557ee0087b827771925',1,'gdf::kernel::Scene']]],
  ['italic',['ITALIC',['../terminal__colors_8h.html#af706885b9b3eb2821dff28f8e7f7bb3f',1,'terminal_colors.h']]]
];
